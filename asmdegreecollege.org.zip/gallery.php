<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>A.S.M. Degree College</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="A.S.M. Degree College" name="keywords">
    <meta content="A.S.M. Degree College" name="description">

    <!-- Favicon -->
    <link href="http://asmdegreecollege.org/img/favicon.ico" rel="icon">
    

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    
<!--    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">-->
<!--  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>-->
<style>
    .courses-list-item .courses-text {
        background: inherit;
    }
    .section-title a{
        margin: 1px 10px;
    }
</style>
    
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid bg-dark">
        <div class="row py-2 px-lg-5">
            <div class="col-lg-6 text-center text-lg-left mb-2 mb-lg-0">
                <div class="d-inline-flex align-items-center text-white">
                    <small><i class="fa fa-phone-alt mr-2"></i>+9170881 80051</small>
                    <small class="px-3">|</small>
                    <small><i class="fa fa-envelope mr-2"></i>info@asmdegreecollege.org</small>
                </div>
            </div>
            <div class="col-lg-6 text-center text-lg-right">
                <div class="d-inline-flex align-items-center">
                    <a class="text-white px-2" href="gallery.php@category=Rangoli.html">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a class="text-white px-2" href="gallery.php@category=Rangoli.html">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a class="text-white px-2" href="gallery.php@category=Rangoli.html">
                        <i class="fab fa-linkedin-in"></i>
                    </a>
                    <a class="text-white px-2" href="gallery.php@category=Rangoli.html">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a class="text-white pl-2" href="gallery.php@category=Rangoli.html">
                        <i class="fab fa-youtube"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid p-0">
        <nav class="navbar navbar-expand-lg bg-white navbar-light py-3 py-lg-0 px-lg-5">
            <a href="index.php.html" class="navbar-brand ml-lg-3">
                <h1 class="m-0 text-uppercase text-primary" style="text-align: right">
                    <table>
                        <tr>
                            <td rowspan="2">
                                <img src="img/slogo.jpg" height="70px"/>
                            </td>
                            <td style="font-size: calc(0.5rem + 0.2vw);width: 100%;">
                                College Code:- 2312
                            </td>
                            
                        </tr>
                        <tr>
                            <td>
                                A.S.M. Degree College
                            </td>
                        </tr>
                        </table>
<!--                    <span><img src="img/slogo.jpg" height="70px"/></span>
                    <span>A.S.M. Degree College</span>
                    
                    <br />
                    <span style="font-size: calc(0.5rem + 0.2vw);width: 100%;">College Code:- 2312</span>-->
                </h1>
                
                
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between px-lg-3" id="navbarCollapse">
                <div class="navbar-nav mx-auto py-0">
                    <a href="index.php.html" class="nav-item nav-link active">Home</a>
<!--                    <a href="about.php" class="nav-item nav-link">About Us</a>-->
                    <div class="nav-item dropdown">
                        <a href="gallery.php@category=Rangoli.html#" class="nav-link dropdown-toggle" data-toggle="dropdown">About</a>
                        <div class="dropdown-menu m-0">
                            <a href="about.php.html" class="dropdown-item">About College</a>
                            <a href="faculty.php.html" class="dropdown-item">Our Faculty</a>
                            <a href="fee.php.html" class="dropdown-item">Fee Structure</a>
                            <a href="message.php@type=Founder.html" class="dropdown-item">Founder Message</a>
                            <a href="message.php@type=President.html" class="dropdown-item">President/Chairman Message</a>
                            <a href="message.php@type=Secretary.html" class="dropdown-item">Secretary Message</a>
                            <a href="message.php@type=Director.html" class="dropdown-item">Director Message</a>
                            <a href="message.php@type=Principle.html" class="dropdown-item">Principle Message</a>
                            
                            
                            
                            
                            
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="gallery.php@category=Rangoli.html#" class="nav-link dropdown-toggle" data-toggle="dropdown">Department</a>
                        <div class="dropdown-menu m-0">
                            <a href="course.php@name=Computer&#32;Application.html" class="dropdown-item">Computer Application</a>
                            <a href="course.php@name=Science.html" class="dropdown-item">Science </a>
                            <a href="course.php@name=Commerce.html" class="dropdown-item">Commerce </a>
                            <a href="course.php@name=Arts.html" class="dropdown-item">Arts </a>
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="gallery.php@category=Rangoli.html#" class="nav-link dropdown-toggle" data-toggle="dropdown">Online</a>
                        <div class="dropdown-menu m-0">
                            <a href="SchoolManagement/registration.php@new.html" class="dropdown-item">New Registration</a>
                            <a href="SchoolManagement/registration.php@login.html" class="dropdown-item">Registration Login</a>
                            <a href="SchoolManagement/index.html" class="dropdown-item">Online Fee Payment</a>
                            <a href="SchoolManagement/index.html" class="dropdown-item">Student/Admin Login</a>
                            <a href="scholarship.php.html" class="dropdown-item">Scholarship Form</a>
                            
                        </div>
                    </div>
                    <a href="gallery.php.html" class="nav-item nav-link">Gallery</a>
                    
                    <a href="contact.php.html" class="nav-item nav-link">Contact Us</a>
                </div>
                
                <a href="SchoolManagement/index.html" class="btn btn-info py-2 px-4 d-lg-block">Pay Fee</a>
                <a href="SchoolManagement/registration.php@new.html" class="btn btn-primary py-2 px-4 d-lg-block">Registration</a>
            </div>
        </nav>
    </div>
    <!-- Navbar End -->

    <div class="jumbotron jumbotron-fluid page-header position-relative overlay-bottom" style="margin-bottom: 0px;">
        <div class="container text-center py-5">
            <h1 class="text-white display-1">Gallery</h1>
            <div class="d-inline-flex text-white mb-5">
                <p class="m-0 text-uppercase"><a class="text-white" href="gallery.php@category=Rangoli.html">Home</a></p>
                <i class="fa fa-angle-double-right pt-1 px-3"></i>
                <p class="m-0 text-uppercase">Gallery</p>
            </div>
        </div>
    </div>


    <!-- Courses Start -->
    <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="row mx-0 justify-content-center">
                <div class="col-lg-8">
                    <div class="section-title text-center position-relative mb-5">
                        <a href='gallery.php.html' class='btn btn-primary'>All</a><a href='gallery.php@category=Rangoli.html' class='btn btn-primary'>Rangoli</a><a href='gallery.php@category=Laptop.html' class='btn btn-primary'>Laptop</a><a href='gallery.php@category=PPP.html' class='btn btn-primary'>PPP</a>                        
<!--                        <h6 class="d-inline-block position-relative text-secondary text-uppercase pb-2">Events</h6>-->
                        <h1 class="display-4">Rangoli</h1>
                    </div>
                </div>
            </div>
            <div class="row">
                                <div class="col-lg-4 col-md-6 pb-4">
                    <a onclick='zoomImg(1)' class="courses-list-item position-relative d-block overflow-hidden mb-2" >
                        <img id="1" class="img-fluid"  src="SchoolManagement/Gallery/Rangoli/Rangoli-1.jpg" alt="">
                        <div class="courses-text">
<!--                            <h4 class="text-center text-white px-3">Web design & development courses for
                                beginners</h4>-->
<!--                            <div class="border-top w-100 mt-3">
                                <div class="d-flex justify-content-between p-4">
                                    <span class="text-white"><i class="fa fa-user mr-2"></i>Jhon Doe</span>
                                    <span class="text-white"><i class="fa fa-star mr-2"></i>4.5
                                        <small>(250)</small></span>
                                </div>
                            </div>-->
                        </div>
                    </a>
                </div>
                                <div class="col-lg-4 col-md-6 pb-4">
                    <a onclick='zoomImg(2)' class="courses-list-item position-relative d-block overflow-hidden mb-2" >
                        <img id="2" class="img-fluid"  src="SchoolManagement/Gallery/Rangoli/Rangoli-2.jpg" alt="">
                        <div class="courses-text">
<!--                            <h4 class="text-center text-white px-3">Web design & development courses for
                                beginners</h4>-->
<!--                            <div class="border-top w-100 mt-3">
                                <div class="d-flex justify-content-between p-4">
                                    <span class="text-white"><i class="fa fa-user mr-2"></i>Jhon Doe</span>
                                    <span class="text-white"><i class="fa fa-star mr-2"></i>4.5
                                        <small>(250)</small></span>
                                </div>
                            </div>-->
                        </div>
                    </a>
                </div>
                                <div class="col-lg-4 col-md-6 pb-4">
                    <a onclick='zoomImg(3)' class="courses-list-item position-relative d-block overflow-hidden mb-2" >
                        <img id="3" class="img-fluid"  src="SchoolManagement/Gallery/Rangoli/Rangoli-3.jpg" alt="">
                        <div class="courses-text">
<!--                            <h4 class="text-center text-white px-3">Web design & development courses for
                                beginners</h4>-->
<!--                            <div class="border-top w-100 mt-3">
                                <div class="d-flex justify-content-between p-4">
                                    <span class="text-white"><i class="fa fa-user mr-2"></i>Jhon Doe</span>
                                    <span class="text-white"><i class="fa fa-star mr-2"></i>4.5
                                        <small>(250)</small></span>
                                </div>
                            </div>-->
                        </div>
                    </a>
                </div>
                                <div class="col-lg-4 col-md-6 pb-4">
                    <a onclick='zoomImg(4)' class="courses-list-item position-relative d-block overflow-hidden mb-2" >
                        <img id="4" class="img-fluid"  src="SchoolManagement/Gallery/Rangoli/Rangoli-6.jpg" alt="">
                        <div class="courses-text">
<!--                            <h4 class="text-center text-white px-3">Web design & development courses for
                                beginners</h4>-->
<!--                            <div class="border-top w-100 mt-3">
                                <div class="d-flex justify-content-between p-4">
                                    <span class="text-white"><i class="fa fa-user mr-2"></i>Jhon Doe</span>
                                    <span class="text-white"><i class="fa fa-star mr-2"></i>4.5
                                        <small>(250)</small></span>
                                </div>
                            </div>-->
                        </div>
                    </a>
                </div>
                                <div class="col-lg-4 col-md-6 pb-4">
                    <a onclick='zoomImg(5)' class="courses-list-item position-relative d-block overflow-hidden mb-2" >
                        <img id="5" class="img-fluid"  src="http://asmdegreecollege.org/SchoolManagement/Gallery/Rangoli/" alt="">
                        <div class="courses-text">
<!--                            <h4 class="text-center text-white px-3">Web design & development courses for
                                beginners</h4>-->
<!--                            <div class="border-top w-100 mt-3">
                                <div class="d-flex justify-content-between p-4">
                                    <span class="text-white"><i class="fa fa-user mr-2"></i>Jhon Doe</span>
                                    <span class="text-white"><i class="fa fa-star mr-2"></i>4.5
                                        <small>(250)</small></span>
                                </div>
                            </div>-->
                        </div>
                    </a>
                </div>
                                <div class="col-lg-4 col-md-6 pb-4">
                    <a onclick='zoomImg(6)' class="courses-list-item position-relative d-block overflow-hidden mb-2" >
                        <img id="6" class="img-fluid"  src="http://asmdegreecollege.org/SchoolManagement/Gallery/Rangoli/" alt="">
                        <div class="courses-text">
<!--                            <h4 class="text-center text-white px-3">Web design & development courses for
                                beginners</h4>-->
<!--                            <div class="border-top w-100 mt-3">
                                <div class="d-flex justify-content-between p-4">
                                    <span class="text-white"><i class="fa fa-user mr-2"></i>Jhon Doe</span>
                                    <span class="text-white"><i class="fa fa-star mr-2"></i>4.5
                                        <small>(250)</small></span>
                                </div>
                            </div>-->
                        </div>
                    </a>
                </div>
                                <script>
                        function zoomImg(id){
                            //alert("working");
                            //alert(document.getElementById(id).style.width);
                            
                            var img = document.getElementById(id).src;
                            window.open(img,"","width=200");
                        }
                        
                    </script>
                
                <div class="col-12" >
                    <nav aria-label="Page navigation">
                        <ul class="pagination pagination-lg justify-content-center mb-0">
                          <li class="page-item disabled">
                            <a class="page-link rounded-0" href="gallery.php@category=Rangoli.html#" aria-label="Previous">
                              <span aria-hidden="true">&laquo;</span>
                              <span class="sr-only">Previous</span>
                            </a>
                          </li>
                          <li class="page-item active"><a class="page-link" href="gallery.php@category=Rangoli.html#">1</a></li>
                          <li class="page-item"><a class="page-link" href="gallery.php@category=Rangoli.html#">2</a></li>
                          <li class="page-item"><a class="page-link" href="gallery.php@category=Rangoli.html#">3</a></li>
                          <li class="page-item">
                            <a class="page-link rounded-0" href="gallery.php@category=Rangoli.html#" aria-label="Next">
                              <span aria-hidden="true">&raquo;</span>
                              <span class="sr-only">Next</span>
                            </a>
                          </li>
                        </ul>
                      </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- Courses End -->


    


    


    <!-- Footer Start -->
    <div class="container-fluid position-relative overlay-top bg-dark text-white-50 py-5" style="margin-top: 90px;">
        <div class="container mt-5 pt-5">
            <div class="row">
                <div class="col-md-6 mb-5">
                    <a href="index.php.html" class="navbar-brand">
                        <h1 class="mt-n2 text-uppercase text-white"><span><img src="img/slogo.jpg" height="70px"/></span> A.S.M. Degree College</h1>
                    </a>
                    <p class="m-0">Amrita Singh Memorial Degree College was established in February 2005, on Vasant 
                        Panchimi which celebrates as birthday of (Maa Saraswati). A.S.M. Degree College came into 
                        existence for the future generations, with the aim of marching on the sacrament and disciplined
                        life path by renowned social worker Mr. Y.P. Singh in the memory of his beloved, Promising & 
                        Talented daughter Late. Kumari. Amrita Singh (B.A, L.L.B). Mr. Singh got this inspiration from
                        Late Shri. Hariom Garg.</p>
                </div>
                <div class="col-md-2 ">
                    </div>
                <div class="col-md-4 mb-5">
                    <h3 class="text-white mb-4">Newsletter</h3>
                    <div class="w-100">
                        <div class="input-group">
                            <input type="text" class="form-control border-light" style="padding: 30px;" placeholder="Your Email Address">
                            <div class="input-group-append">
                                <button class="btn btn-primary px-4">Sign Up</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-5">
                    <h3 class="text-white mb-4">Get In Touch</h3>
                    <p><i class="fa fa-map-marker-alt mr-2"></i>NH-93 Tejpur, Aligarh , Uttar Pradesh, India</p>
                    <p><i class="fa fa-phone-alt mr-2"></i>+91 7088180051, 9412275307</p>
                    <p><i class="fa fa-envelope mr-2"></i>info@asmdegreecollege.org</p>
                    <div class="d-flex justify-content-start mt-4">
                        <a class="text-white mr-4" href="gallery.php@category=Rangoli.html#"><i class="fab fa-2x fa-twitter"></i></a>
                        <a class="text-white mr-4" href="gallery.php@category=Rangoli.html#"><i class="fab fa-2x fa-facebook-f"></i></a>
                        <a class="text-white mr-4" href="gallery.php@category=Rangoli.html#"><i class="fab fa-2x fa-linkedin-in"></i></a>
                        <a class="text-white" href="gallery.php@category=Rangoli.html#"><i class="fab fa-2x fa-instagram"></i></a>
                    </div>
                </div>
                <div class="col-md-4 mb-5">
                    <h3 class="text-white mb-4">Our Courses</h3>
                    <div class="d-flex flex-column justify-content-start">
                        <a class="text-white-50 mb-2" href="course.php@name=Computer&#32;Application.html"><i class="fa fa-angle-right mr-2"></i>Computer Application</a>
                        <a class="text-white-50 mb-2" href="course.php@name=Science.html"><i class="fa fa-angle-right mr-2"></i>Science Department</a>
                        <a class="text-white-50 mb-2" href="course.php@name=Commerce.html"><i class="fa fa-angle-right mr-2"></i>Commerce Department</a>
                        <a class="text-white-50 mb-2" href="course.php@name=Arts.html"><i class="fa fa-angle-right mr-2"></i>Art Department</a>
                        <a class="text-white-50 mb-2" href="fee.php.html"><i class="fa fa-angle-right mr-2"></i>Fee Structure</a>
                        
                    </div>
                </div>
                <div class="col-md-4 mb-5">
                    <h3 class="text-white mb-4">Quick Links</h3>
                    <div class="d-flex flex-column justify-content-start">
                        <a class="text-white-50 mb-2" href="about.php.html"><i class="fa fa-angle-right mr-2"></i>About Us</a>
                        <a class="text-white-50 mb-2" href="SchoolManagement/registration.php@new.html"><i class="fa fa-angle-right mr-2"></i>Online Registration</a>
                        <a class="text-white-50 mb-2" href="SchoolManagement/registration.php@login.html"><i class="fa fa-angle-right mr-2"></i>Registration Login</a>
                        <a class="text-white-50 mb-2" href="SchoolManagement/index.html"><i class="fa fa-angle-right mr-2"></i>Online Fee Payment</a>
                        <a class="text-white-50 mb-2" href="SchoolManagement/index.html"><i class="fa fa-angle-right mr-2"></i>Student/Admin Login</a>
                        
                        <a class="text-white-50" href="contact.php.html"><i class="fa fa-angle-right mr-2"></i>Contact</a>
                        <a class="text-white-50" href="terms.php.html"><i class="fa fa-angle-right mr-2"></i>Terms and Conditions</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid bg-dark text-white-50 border-top py-4" style="border-color: rgba(256, 256, 256, .1) !important;">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-center text-md-left mb-3 mb-md-0">
                    <p class="m-0">Copyright &copy; <a class="text-white" href="gallery.php@category=Rangoli.html#">A.S.M. Degree College</a>. All Rights Reserved.
                    </p>
                </div>
                <div class="col-md-6 text-center text-md-right">
                    <p class="m-0">Designed by <a class="text-white" href="https://andwebtech.com">A & D Technology</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
    <!-- Back to Top -->
    <a href="gallery.php@category=Rangoli.html#" class="btn btn-lg btn-primary rounded-0 btn-lg-square back-to-top"><i class="fa fa-angle-double-up"></i></a>
    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>

    


    
</body>

</html>