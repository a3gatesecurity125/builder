<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>A.S.M. Degree College</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="A.S.M. Degree College" name="keywords">
    <meta content="A.S.M. Degree College" name="description">

    <!-- Favicon -->
    <link href="http://asmdegreecollege.org/img/favicon.ico" rel="icon">
    

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    
<!--    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid bg-dark">
        <div class="row py-2 px-lg-5">
            <div class="col-lg-6 text-center text-lg-left mb-2 mb-lg-0">
                <div class="d-inline-flex align-items-center text-white">
                    <small><i class="fa fa-phone-alt mr-2"></i>+9170881 80051</small>
                    <small class="px-3">|</small>
                    <small><i class="fa fa-envelope mr-2"></i>info@asmdegreecollege.org</small>
                </div>
            </div>
            <div class="col-lg-6 text-center text-lg-right">
                <div class="d-inline-flex align-items-center">
                    <a class="text-white px-2" href="index.php.html">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a class="text-white px-2" href="index.php.html">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a class="text-white px-2" href="index.php.html">
                        <i class="fab fa-linkedin-in"></i>
                    </a>
                    <a class="text-white px-2" href="index.php.html">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a class="text-white pl-2" href="index.php.html">
                        <i class="fab fa-youtube"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid p-0">
        <nav class="navbar navbar-expand-lg bg-white navbar-light py-3 py-lg-0 px-lg-5">
            <a href="index.php.html" class="navbar-brand ml-lg-3">
                <h1 class="m-0 text-uppercase text-primary" style="text-align: right">
                    <table>
                        <tr>
                            <td rowspan="2">
                                <img src="img/slogo.jpg" height="70px"/>
                            </td>
                            <td style="font-size: calc(0.5rem + 0.2vw);width: 100%;">
                                College Code:- 2312
                            </td>
                            
                        </tr>
                        <tr>
                            <td>
                                A.S.M. Degree College
                            </td>
                        </tr>
                        </table>
<!--                    <span><img src="img/slogo.jpg" height="70px"/></span>
                    <span>A.S.M. Degree College</span>
                    
                    <br />
                    <span style="font-size: calc(0.5rem + 0.2vw);width: 100%;">College Code:- 2312</span>-->
                </h1>
                
                
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between px-lg-3" id="navbarCollapse">
                <div class="navbar-nav mx-auto py-0">
                    <a href="index.php.html" class="nav-item nav-link active">Home</a>
<!--                    <a href="about.php" class="nav-item nav-link">About Us</a>-->
                    <div class="nav-item dropdown">
                        <a href="index.php.html#" class="nav-link dropdown-toggle" data-toggle="dropdown">About</a>
                        <div class="dropdown-menu m-0">
                            <a href="about.php.html" class="dropdown-item">About College</a>
                            <a href="faculty.php.html" class="dropdown-item">Our Faculty</a>
                            <a href="fee.php.html" class="dropdown-item">Fee Structure</a>
                            <a href="message.php@type=Founder.html" class="dropdown-item">Founder Message</a>
                            <a href="message.php@type=President.html" class="dropdown-item">President/Chairman Message</a>
                            <a href="message.php@type=Secretary.html" class="dropdown-item">Secretary Message</a>
                            <a href="message.php@type=Director.html" class="dropdown-item">Director Message</a>
                            <a href="message.php@type=Principle.html" class="dropdown-item">Principle Message</a>
                            
                            
                            
                            
                            
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="index.php.html#" class="nav-link dropdown-toggle" data-toggle="dropdown">Department</a>
                        <div class="dropdown-menu m-0">
                            <a href="course.php@name=Computer&#32;Application.html" class="dropdown-item">Computer Application</a>
                            <a href="course.php@name=Science.html" class="dropdown-item">Science </a>
                            <a href="course.php@name=Commerce.html" class="dropdown-item">Commerce </a>
                            <a href="course.php@name=Arts.html" class="dropdown-item">Arts </a>
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="index.php.html#" class="nav-link dropdown-toggle" data-toggle="dropdown">Online</a>
                        <div class="dropdown-menu m-0">
                            <a href="SchoolManagement/registration.php@new.html" class="dropdown-item">New Registration</a>
                            <a href="SchoolManagement/registration.php@login.html" class="dropdown-item">Registration Login</a>
                            <a href="SchoolManagement/index.html" class="dropdown-item">Online Fee Payment</a>
                            <a href="SchoolManagement/index.html" class="dropdown-item">Student/Admin Login</a>
                            <a href="scholarship.php.html" class="dropdown-item">Scholarship Form</a>
                            
                        </div>
                    </div>
                    <a href="gallery.php.html" class="nav-item nav-link">Gallery</a>
                    
                    <a href="contact.php.html" class="nav-item nav-link">Contact Us</a>
                </div>
                
                <a href="SchoolManagement/index.html" class="btn btn-info py-2 px-4 d-lg-block">Pay Fee</a>
                <a href="SchoolManagement/registration.php@new.html" class="btn btn-primary py-2 px-4 d-lg-block">Registration</a>
            </div>
        </nav>
    </div>
    <!-- Navbar End -->

    <!-- Header Start -->
    <div class="">
        
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
          <!-- Indicators -->
          <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
          </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner">

              <div class="item active">
                  <img src="img/ban1.jpg" alt="A S M Degree College" style="width:100%;">
                <div class="carousel-caption">
                  
                </div>
              </div>

              <div class="item">
                <img src="img/ban2.jpg" alt="A S M Degree College" style="width:100%;">
                <div class="carousel-caption">
                  
                </div>
              </div>

              <div class="item">
                <img src="img/ban3.jpg" alt="A S M Degree College" style="width:100%;">
                <div class="carousel-caption">
                  
                </div>
              </div>

            </div>

            <!-- Left and right controls -->
            <a class="left carousel-control" href="index.php.html#myCarousel" data-slide="prev">
              <span class="glyphicon glyphicon-chevron-left"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="index.php.html#myCarousel" data-slide="next">
              <span class="glyphicon glyphicon-chevron-right"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>
        </div>
    <div class="jumbotron jumbotron-fluid position-relative overlay-bottom" style="display:none;margin-bottom: 90px;">
        
        
        
        

        <div class="container text-center my-5 py-5" style="display:none;">
            <h1 class="text-white mt-4 mb-4" >Learn From Home</h1>
            <h1 class="text-white display-1 mb-5">Education Courses</h1>
            <div class="mx-auto mb-5" style="display:none;width: 100%; max-width: 600px;">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <button class="btn btn-outline-light bg-white text-body px-4 dropdown-toggle" type="button" data-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">Courses</button>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="index.php.html#">Courses 1</a>
                            <a class="dropdown-item" href="index.php.html#">Courses 2</a>
                            <a class="dropdown-item" href="index.php.html#">Courses 3</a>
                        </div>
                    </div>
                    <input type="text" class="form-control border-light" style="padding: 30px 25px;" placeholder="Keyword">
                    <div class="input-group-append">
                        <button class="btn btn-secondary px-4 px-lg-5">Search</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->


    <!-- About Start -->
    <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="row">
                <div class="col-lg-4 mb-5 mb-lg-0 mainpic" style="">
                    <div class="position-relative h-100">
                        <img class="position-absolute w-100 h-100" src="img/new-0682.jpg" style="object-fit: contain;">
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="section-title position-relative mb-4">
                        <h6 class="d-inline-block position-relative text-secondary text-uppercase pb-2">About Us</h6>
                        <h1 class="display-4">A.S.M. Degree College</h1>
                    </div>
                    <p>Amrita Singh Memorial Degree College was established in February 2005, on Vasant Panchimi which celebrates as birthday of (Maa Saraswati).
A.S.M. Degree College came into existence for the future generations, with the aim of marching on the sacrament and disciplined life path by renowned social worker Mr. Y.P. Singh in the memory of his beloved, Promising & Talented daughter Late. Kumari. Amrita Singh (B.A, L.L.B).
Mr. Singh got this inspiration from Late Shri. Hariom Garg.</p>
                    <p>To give a new direction to the society, He has established Amrita Singh Memorial Trust and in 2005 to place his main objectives in the society and make Amrita Singh Memorial degree College operational, he got affiliation of Arts (B.A) in seven subjects from Raja Mahendra Pratap Singh State University, Aligarh </p>
                    <div class="row pt-3 mx-0">
                        <div class="col-3 px-0">
                            <div class="bg-success text-center p-4">
                                <h1 class="text-white" data-toggle="counter-up">20</h1>
                                <h6 class="text-uppercase text-white">Available<span class="d-block">Subjects</span></h6>
                            </div>
                        </div>
                        <div class="col-3 px-0">
                            <div class="bg-primary text-center p-4">
                                <h1 class="text-white" data-toggle="counter-up">10</h1>
                                <h6 class="text-uppercase text-white">Available<span class="d-block">Courses</span></h6>
                            </div>
                        </div>
                        <div class="col-3 px-0">
                            <div class="bg-secondary text-center p-4">
                                <h1 class="text-white" data-toggle="counter-up">60</h1>
                                <h6 class="text-uppercase text-white">Skilled<span class="d-block">Instructors</span></h6>
                            </div>
                        </div>
                        <div class="col-3 px-0">
                            <div class="bg-warning text-center p-4">
                                <h1 class="text-white" data-toggle="counter-up">1200</h1>
                                <h6 class="text-uppercase text-white">Happy<span class="d-block">Students</span></h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->


    <!-- Feature Start -->
    <div class="container-fluid bg-image" style="margin: 90px 0;">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 my-5 pt-5 pb-lg-5">
                    <div class="section-title position-relative mb-4">
                        <h6 class="d-inline-block position-relative text-secondary text-uppercase pb-2">Why Choose Us?</h6>
                        <h1 class="display-4">Why You Should Start Learning with Us?</h1>
                    </div>
                    <p class="mb-4 pb-2">Introducing different method approaches, ASM Degree College is the first institution of its kind in Aligarh. This college offer Courses like BA, BSC, BCA, BCOM, MA, MSC and ITI. At present more than 1200 students are admitted to this centre. This college is located at NH-93 Tejpur, Aligarh.</p>
                    <div class="d-flex mb-3">
                        <div class="btn-icon bg-primary mr-4">
                            <i class="fa fa-2x fa-graduation-cap text-white"></i>
                        </div>
                        <div class="mt-n1">
                            <h4>Skilled Instructors</h4>
                            <p>The college aims at imparting modern Scientific Education along with the teaching of valuable things to students.</p>
                        </div>
                    </div>
                    <div class="d-flex mb-3">
                        <div class="btn-icon bg-secondary mr-4">
                            <i class="fa fa-2x fa-certificate text-white"></i>
                        </div>
                        <div class="mt-n1">
                            <h4>Education Program</h4>
                            <p>ASM Degree College provides ample facilities of Game and Sports with well trained coaches for students</p>
                        </div>
                    </div>
                    <div class="d-flex">
                        <div class="btn-icon bg-warning mr-4">
                            <i class="fa fa-2x fa-book-reader text-white"></i>
                        </div>
                        <div class="mt-n1">
                            <h4>Online Classes</h4>
                            <p class="m-0">We offer online classess to students for different subject and courses regularly</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6" style="min-height: 500px;">
                    <div class="position-relative h-100">
                        <img class="position-absolute w-100 h-100" src="img/feature1.jpg" style="object-fit: cover;">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Feature Start -->


    <!-- Courses Start -->
    <div class="container-fluid px-0 py-5">
        <div class="row mx-0 justify-content-center pt-5">
            <div class="col-lg-6">
                <div class="section-title text-center position-relative mb-4">
                    <h6 class="d-inline-block position-relative text-secondary text-uppercase pb-2">Our Courses</h6>
                    <h1 class="display-4">Checkout New Releases Of Our Courses</h1>
                </div>
            </div>
        </div>
        <div class="owl-carousel courses-carousel">
            <div class="courses-item position-relative">
                <img class="img-fluid" src="img/courses-4.jpg" alt="">
                <div class="courses-text">
                    <h4 class="text-center text-white px-3">Computer Application</h4>
                    <div class="border-top w-100 mt-3">
                        <div class="d-flex justify-content-between p-4">
                            <span class="text-white"><i class="fa fa-user mr-2"></i>Head</span>
                            <span class="text-white"><i class="fa fa-star mr-2"></i>4.5 <small>(250)</small></span>
                        </div>
                    </div>
                    <div class="w-100 bg-white text-center p-4" >
                        <a class="btn btn-primary" href="course.php@name=Computer&#32;Application.html">Course Detail</a>
                    </div>
                </div>
            </div>
            <div class="courses-item position-relative">
                <img class="img-fluid" src="img/science-bg.png" alt="">
                <div class="courses-text">
                    <h4 class="text-center text-white px-3">Science Department</h4>
                    <div class="border-top w-100 mt-3">
                        <div class="d-flex justify-content-between p-4">
                            <span class="text-white"><i class="fa fa-user mr-2"></i>Head</span>
                            <span class="text-white"><i class="fa fa-star mr-2"></i>4.5 <small>(250)</small></span>
                        </div>
                    </div>
                    <div class="w-100 bg-white text-center p-4" >
                        <a class="btn btn-primary" href="course.php@name=Science.html">Course Detail</a>
                    </div>
                </div>
            </div>
            <div class="courses-item position-relative">
                <img class="img-fluid" src="img/commerce.jpg" alt="">
                <div class="courses-text">
                    <h4 class="text-center text-white px-3">Commerce Department</h4>
                    <div class="border-top w-100 mt-3">
                        <div class="d-flex justify-content-between p-4">
                            <span class="text-white"><i class="fa fa-user mr-2"></i>Head</span>
                            <span class="text-white"><i class="fa fa-star mr-2"></i>4.5 <small>(250)</small></span>
                        </div>
                    </div>
                    <div class="w-100 bg-white text-center p-4" >
                        <a class="btn btn-primary" href="course.php@name=Commerce.html">Course Detail</a>
                    </div>
                </div>
            </div>
            <div class="courses-item position-relative">
                <img class="img-fluid" src="img/subjects-in-arts.jpg" alt="">
                <div class="courses-text">
                    <h4 class="text-center text-white px-3">Arts Department</h4>
                    <div class="border-top w-100 mt-3">
                        <div class="d-flex justify-content-between p-4">
                            <span class="text-white"><i class="fa fa-user mr-2"></i>Head</span>
                            <span class="text-white"><i class="fa fa-star mr-2"></i>4.5 <small>(250)</small></span>
                        </div>
                    </div>
                    <div class="w-100 bg-white text-center p-4" >
                        <a class="btn btn-primary" href="course.php@name=Arts.html">Course Detail</a>
                    </div>
                </div>
            </div>
            
        </div>
        <div class="row justify-content-center bg-image mx-0 mb-5" style="display: none;">
            <div class="col-lg-6 py-5">
                <div class="bg-white p-5 my-5">
                    <h1 class="text-center mb-4">30% Off For New Students</h1>
                    <form>
                        <div class="form-row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <input type="text" class="form-control bg-light border-0" placeholder="Your Name" style="padding: 30px 20px;">
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <input type="email" class="form-control bg-light border-0" placeholder="Your Email" style="padding: 30px 20px;">
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <select class="custom-select bg-light border-0 px-3" style="height: 60px;">
                                        <option selected>Select A courses</option>
                                        <option value="1">courses 1</option>
                                        <option value="2">courses 1</option>
                                        <option value="3">courses 1</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <button class="btn btn-primary btn-block" type="submit" style="height: 60px;">Sign Up Now</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Courses End -->


    <!-- Team Start -->
    <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="section-title text-center position-relative mb-5">
                <h6 class="d-inline-block position-relative text-secondary text-uppercase pb-2">Instructors</h6>
                <h1 class="display-4">Meet Our Instructors</h1>
            </div>
            <div class="owl-carousel team-carousel position-relative" style="padding: 0 30px;">
                <div class="team-item">
                    <img class="img-fluid w-100" src="img/founder.jpeg" alt="">
                    <div class="bg-light text-center p-4">
                        <h5 class="mb-3">श्री वाई.पी. सिंह (M.S.W)</h5>
                        <p class="mb-2">Founder</p>
                        <div class="d-flex justify-content-center">
                            <a class="mx-1 p-1" href="index.php.html#"><i class="fab fa-twitter"></i></a>
                            <a class="mx-1 p-1" href="index.php.html#"><i class="fab fa-facebook-f"></i></a>
                            <a class="mx-1 p-1" href="index.php.html#"><i class="fab fa-linkedin-in"></i></a>
                            <a class="mx-1 p-1" href="index.php.html#"><i class="fab fa-instagram"></i></a>
                            <a class="mx-1 p-1" href="index.php.html#"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>
                </div>
                <div class="team-item">
                    <img class="img-fluid w-100" src="img/president.jpeg" alt="">
                    <div class="bg-light text-center p-4">
                        <h5 class="mb-3">श्री एस.के. सिंह (एडवोकेट)</h5>
                        <p class="mb-2">President/Chairman</p>
                        <div class="d-flex justify-content-center">
                            <a class="mx-1 p-1" href="index.php.html#"><i class="fab fa-twitter"></i></a>
                            <a class="mx-1 p-1" href="index.php.html#"><i class="fab fa-facebook-f"></i></a>
                            <a class="mx-1 p-1" href="index.php.html#"><i class="fab fa-linkedin-in"></i></a>
                            <a class="mx-1 p-1" href="index.php.html#"><i class="fab fa-instagram"></i></a>
                            <a class="mx-1 p-1" href="index.php.html#"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>
                </div>
                <div class="team-item">
                    <img class="img-fluid w-100" src="img/secretary.jpeg" alt="">
                    <div class="bg-light text-center p-4">
                        <h5 class="mb-3">विक्रम सिंह (इन्जीनियर)</h5>
                        <p class="mb-2">Secretary</p>
                        <div class="d-flex justify-content-center">
                            <a class="mx-1 p-1" href="index.php.html#"><i class="fab fa-twitter"></i></a>
                            <a class="mx-1 p-1" href="index.php.html#"><i class="fab fa-facebook-f"></i></a>
                            <a class="mx-1 p-1" href="index.php.html#"><i class="fab fa-linkedin-in"></i></a>
                            <a class="mx-1 p-1" href="index.php.html#"><i class="fab fa-instagram"></i></a>
                            <a class="mx-1 p-1" href="index.php.html#"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>
                </div>
                <div class="team-item">
                    <img class="img-fluid w-100" src="img/director.jpeg" alt="">
                    <div class="bg-light text-center p-4">
                        <h5 class="mb-3">श्रीमती अर्चना सिंह</h5>
                        <p class="mb-2">Director</p>
                        <div class="d-flex justify-content-center">
                            <a class="mx-1 p-1" href="index.php.html#"><i class="fab fa-twitter"></i></a>
                            <a class="mx-1 p-1" href="index.php.html#"><i class="fab fa-facebook-f"></i></a>
                            <a class="mx-1 p-1" href="index.php.html#"><i class="fab fa-linkedin-in"></i></a>
                            <a class="mx-1 p-1" href="index.php.html#"><i class="fab fa-instagram"></i></a>
                            <a class="mx-1 p-1" href="index.php.html#"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <!-- Team End -->


    <!-- Testimonial Start -->
    <div class="container-fluid bg-image py-5" style="margin: 90px 0;">
        <div class="container py-5">
            <div class="row align-items-center">
                <div class="col-lg-5 mb-5 mb-lg-0">
                    <div class="section-title position-relative mb-4">
                        <h6 class="d-inline-block position-relative text-secondary text-uppercase pb-2">Testimonial</h6>
                        <h1 class="display-4">Instructors Message</h1>
                    </div>
                    <p class="m-0"></p>
                </div>
                <div class="col-lg-7">
                    <div class="owl-carousel testimonial-carousel">
                        <div class="bg-white p-5">
                            <i class="fa fa-3x fa-quote-left text-primary mb-4"></i>
                            <p>Greetings and welcome to ASM Degree College which has taken a brisk and giant stride in
                                this Indian sub-continent since 2004. I am highly honoured to superintend this institute
                                which, over these years, has become a part of my very being along with its irrefutable 
                                innovations in the field of training and child personality development. The guiding
                                principles of the institute are ‘creation of awareness, competence and proficiency’ 
                                among students so that they can face the life-challenges with their broad shoulders and
                                ever shy away from the difficulties of any sphere of life. </p>
                            <div class="d-flex flex-shrink-0 align-items-center mt-4">
                                <img class="img-fluid mr-4" src="img/team.jpg" alt="">
                                <div>
                                    <h5>श्री वाई.पी. सिंह (M.S.W)</h5>
                                    <span>Founder</span>
                                </div>
                            </div>
                        </div>
                        <div class="bg-white p-5">
                            <i class="fa fa-3x fa-quote-left text-primary mb-4"></i>
                            <p>Greetings and welcome to ASM Degree College which has taken a brisk and giant stride in
                                this Indian sub-continent since 2004. I am highly honoured to superintend this institute
                                which, over these years, has become a part of my very being along with its irrefutable 
                                innovations in the field of training and child personality development. The guiding
                                principles of the institute are ‘creation of awareness, competence and proficiency’ 
                                among students so that they can face the life-challenges with their broad shoulders and
                                ever shy away from the difficulties of any sphere of life. </p>
                            <div class="d-flex flex-shrink-0 align-items-center mt-4">
                                <img class="img-fluid mr-4" src="img/team.jpg" alt="">
                                <div>
                                    <h5>श्री एस.के. सिंह (एडवोकेट)</h5>
                        
                                    <span>President/Chairman</span>
                                </div>
                            </div>
                        </div>
                        <div class="bg-white p-5">
                            <i class="fa fa-3x fa-quote-left text-primary mb-4"></i>
                            <p>Greetings and welcome to ASM Degree College which has taken a brisk and giant stride in
                                this Indian sub-continent since 2004. I am highly honoured to superintend this institute
                                which, over these years, has become a part of my very being along with its irrefutable 
                                innovations in the field of training and child personality development. The guiding
                                principles of the institute are ‘creation of awareness, competence and proficiency’ 
                                among students so that they can face the life-challenges with their broad shoulders and
                                ever shy away from the difficulties of any sphere of life. </p>
                            <div class="d-flex flex-shrink-0 align-items-center mt-4">
                                <img class="img-fluid mr-4" src="img/team.jpg" alt="">
                                <div>
                                    <h5>विक्रम सिंह (इन्जीनियर)</h5>
                                    <span>Secretary</span>
                                </div>
                            </div>
                        </div>
                        <div class="bg-white p-5">
                            <i class="fa fa-3x fa-quote-left text-primary mb-4"></i>
                            <p>Greetings and welcome to ASM Degree College which has taken a brisk and giant stride in
                                this Indian sub-continent since 2004. I am highly honoured to superintend this institute
                                which, over these years, has become a part of my very being along with its irrefutable 
                                innovations in the field of training and child personality development. The guiding
                                principles of the institute are ‘creation of awareness, competence and proficiency’ 
                                among students so that they can face the life-challenges with their broad shoulders and
                                ever shy away from the difficulties of any sphere of life. </p>
                            <div class="d-flex flex-shrink-0 align-items-center mt-4">
                                <img class="img-fluid mr-4" src="img/team.jpg" alt="">
                                <div>
                                    <h5>श्रीमती अर्चना सिंह</h5>
                        
                                    <span>Director</span>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Testimonial Start -->


    <!-- Contact Start -->
    <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="row align-items-center">
                <div class="col-lg-5 mb-5 mb-lg-0">
                    <div class="bg-light d-flex flex-column justify-content-center px-5" style="height: 450px;">
                        <div class="d-flex align-items-center mb-5">
                            <div class="btn-icon bg-primary mr-4">
                                <i class="fa fa-2x fa-map-marker-alt text-white"></i>
                            </div>
                            <div class="mt-n1">
                                <h4>Our Location</h4>
                                <p class="m-0">NH-93 Tejpur, Aligarh , Uttar Pradesh, India</p>
                            </div>
                        </div>
                        <div class="d-flex align-items-center mb-5">
                            <div class="btn-icon bg-secondary mr-4">
                                <i class="fa fa-2x fa-phone-alt text-white"></i>
                            </div>
                            <div class="mt-n1">
                                <h4>Call Us</h4>
                                <p class="m-0">+91 9412275307, 9411041647, 9759171250</p>
                            </div>
                        </div>
                        <div class="d-flex align-items-center">
                            <div class="btn-icon bg-warning mr-4">
                                <i class="fa fa-2x fa-envelope text-white"></i>
                            </div>
                            <div class="mt-n1">
                                <h4>Email Us</h4>
                                <p class="m-0">info@asmdegreecollege.com</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="section-title position-relative mb-4">
                        <h6 class="d-inline-block position-relative text-secondary text-uppercase pb-2">Need Help?</h6>
                        <h1 class="display-4">Send Us A Message</h1>
                    </div>
                    <div class="contact-form">
                        <form>
                            <div class="row">
                                <div class="col-6 form-group">
                                    <input type="text" class="form-control border-top-0 border-right-0 border-left-0 p-0" placeholder="Your Name" required="required">
                                </div>
                                <div class="col-6 form-group">
                                    <input type="email" class="form-control border-top-0 border-right-0 border-left-0 p-0" placeholder="Your Email" required="required">
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control border-top-0 border-right-0 border-left-0 p-0" placeholder="Subject" required="required">
                            </div>
                            <div class="form-group">
                                <textarea class="form-control border-top-0 border-right-0 border-left-0 p-0" rows="5" placeholder="Message" required="required"></textarea>
                            </div>
                            <div>
                                <button class="btn btn-primary py-3 px-5" type="submit">Send Message</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Contact End -->


    <!-- Footer Start -->
    <div class="container-fluid position-relative overlay-top bg-dark text-white-50 py-5" style="margin-top: 90px;">
        <div class="container mt-5 pt-5">
            <div class="row">
                <div class="col-md-6 mb-5">
                    <a href="index.php.html" class="navbar-brand">
                        <h1 class="mt-n2 text-uppercase text-white"><span><img src="img/slogo.jpg" height="70px"/></span> A.S.M. Degree College</h1>
                    </a>
                    <p class="m-0">Amrita Singh Memorial Degree College was established in February 2005, on Vasant 
                        Panchimi which celebrates as birthday of (Maa Saraswati). A.S.M. Degree College came into 
                        existence for the future generations, with the aim of marching on the sacrament and disciplined
                        life path by renowned social worker Mr. Y.P. Singh in the memory of his beloved, Promising & 
                        Talented daughter Late. Kumari. Amrita Singh (B.A, L.L.B). Mr. Singh got this inspiration from
                        Late Shri. Hariom Garg.</p>
                </div>
                <div class="col-md-2 ">
                    </div>
                <div class="col-md-4 mb-5">
                    <h3 class="text-white mb-4">Newsletter</h3>
                    <div class="w-100">
                        <div class="input-group">
                            <input type="text" class="form-control border-light" style="padding: 30px;" placeholder="Your Email Address">
                            <div class="input-group-append">
                                <button class="btn btn-primary px-4">Sign Up</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-5">
                    <h3 class="text-white mb-4">Get In Touch</h3>
                    <p><i class="fa fa-map-marker-alt mr-2"></i>NH-93 Tejpur, Aligarh , Uttar Pradesh, India</p>
                    <p><i class="fa fa-phone-alt mr-2"></i>+91 7088180051, 9412275307</p>
                    <p><i class="fa fa-envelope mr-2"></i>info@asmdegreecollege.org</p>
                    <div class="d-flex justify-content-start mt-4">
                        <a class="text-white mr-4" href="index.php.html#"><i class="fab fa-2x fa-twitter"></i></a>
                        <a class="text-white mr-4" href="index.php.html#"><i class="fab fa-2x fa-facebook-f"></i></a>
                        <a class="text-white mr-4" href="index.php.html#"><i class="fab fa-2x fa-linkedin-in"></i></a>
                        <a class="text-white" href="index.php.html#"><i class="fab fa-2x fa-instagram"></i></a>
                    </div>
                </div>
                <div class="col-md-4 mb-5">
                    <h3 class="text-white mb-4">Our Courses</h3>
                    <div class="d-flex flex-column justify-content-start">
                        <a class="text-white-50 mb-2" href="course.php@name=Computer&#32;Application.html"><i class="fa fa-angle-right mr-2"></i>Computer Application</a>
                        <a class="text-white-50 mb-2" href="course.php@name=Science.html"><i class="fa fa-angle-right mr-2"></i>Science Department</a>
                        <a class="text-white-50 mb-2" href="course.php@name=Commerce.html"><i class="fa fa-angle-right mr-2"></i>Commerce Department</a>
                        <a class="text-white-50 mb-2" href="course.php@name=Arts.html"><i class="fa fa-angle-right mr-2"></i>Art Department</a>
                        <a class="text-white-50 mb-2" href="fee.php.html"><i class="fa fa-angle-right mr-2"></i>Fee Structure</a>
                        
                    </div>
                </div>
                <div class="col-md-4 mb-5">
                    <h3 class="text-white mb-4">Quick Links</h3>
                    <div class="d-flex flex-column justify-content-start">
                        <a class="text-white-50 mb-2" href="about.php.html"><i class="fa fa-angle-right mr-2"></i>About Us</a>
                        <a class="text-white-50 mb-2" href="SchoolManagement/registration.php@new.html"><i class="fa fa-angle-right mr-2"></i>Online Registration</a>
                        <a class="text-white-50 mb-2" href="SchoolManagement/registration.php@login.html"><i class="fa fa-angle-right mr-2"></i>Registration Login</a>
                        <a class="text-white-50 mb-2" href="SchoolManagement/index.html"><i class="fa fa-angle-right mr-2"></i>Online Fee Payment</a>
                        <a class="text-white-50 mb-2" href="SchoolManagement/index.html"><i class="fa fa-angle-right mr-2"></i>Student/Admin Login</a>
                        
                        <a class="text-white-50" href="contact.php.html"><i class="fa fa-angle-right mr-2"></i>Contact</a>
                        <a class="text-white-50" href="terms.php.html"><i class="fa fa-angle-right mr-2"></i>Terms and Conditions</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid bg-dark text-white-50 border-top py-4" style="border-color: rgba(256, 256, 256, .1) !important;">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-center text-md-left mb-3 mb-md-0">
                    <p class="m-0">Copyright &copy; <a class="text-white" href="index.php.html#">A.S.M. Degree College</a>. All Rights Reserved.
                    </p>
                </div>
                <div class="col-md-6 text-center text-md-right">
                    <p class="m-0">Designed by <a class="text-white" href="https://andwebtech.com">A & D Technology</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
    <!-- Back to Top -->
    <a href="index.php.html#" class="btn btn-lg btn-primary rounded-0 btn-lg-square back-to-top"><i class="fa fa-angle-double-up"></i></a>
    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>

    


    
</body>

</html>