


var word2 = new Array();
function changeDateFormat(cDate) {
    word2 = cDate.split("-");
    var newDate = word2[2] + "/" + word2[1] + "/" + word2[0];
    var req = new XMLHttpRequest();
    req.open("POST", "include/setDateToSession.php", true);
    req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    req.send("cDate=" + newDate);
}
function callChangeDate() {
}

function toggleInputBoxsActiveDisabled() {
    var feeMasterBoxId = [
        "totalFeeInst", "totalFee", "annualFee",
        "cautionMoney", "admissionFee", "examFeeBox",
        "monthlyFee"
    ];
    for (var i = 0; i < 7; i++) {
//        alert(feeMasterBoxId[i]);
        document.getElementById(feeMasterBoxId[i]).disabled 
                document.getElementById(feeMasterBoxId[i]).disabled;

    }
}