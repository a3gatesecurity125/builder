<html>
    <head>
                <!-- Latest compiled and minified CSS -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script>
            function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("cont").style.display = "block";
}


$(document).ready(function(){
    ////for enter behave like tab optional
//$('input').on("keypress", function(e) {
//            /* ENTER PRESSED*/
//            if (e.keyCode == 13) {
//                /* FOCUS ELEMENT */
//                var inputs = $(this).parents("form").eq(0).find(":input");
//                var idx = inputs.index(this);
//
//                if (idx == inputs.length - 1) {
//                    inputs[0].select()
//                } else {
//                    inputs[idx + 1].focus(); //  handles submit buttons
//                    inputs[idx + 1].select();
//                }
//                return false;
//            }
//        });

//for enter behave like tab
$('input').keydown( function(e) {
        var key = e.charCode ? e.charCode : e.keyCode ? e.keyCode : 0;
        if(key == 13) {
            e.preventDefault();
            var inputs = $(this).closest('form').find(':input:visible:not([readonly])');
            inputs.eq( inputs.index(this) + 1 ).focus();
        }
    });

//for backspace behave like shift+tab
        $('input').keydown( function(e) {
        var key = e.charCode ? e.charCode : e.keyCode ? e.keyCode : 0;
        if(key == 8) {
            
            var inputs = $(this).closest('form').find(':input:visible');
            //alert(inputs.eq( inputs.index(this)).val());
            if(inputs.eq( inputs.index(this)).val() == ''){
                e.preventDefault();
                inputs.eq( inputs.index(this) - 1 ).focus();
            }
            
        }
    });

        });
        
        
        function chkSt(val){
var x = document.getElementsByName(val)[0].value;
var parentID = document.getElementById(val);

var subs = parentID.getElementsByTagName('OPTION');
    for(var i = 0; i < subs.length; i++){
       var a = subs[i];
       if(a.value == x)
       {
           return false;
       }
    }
document.getElementsByName(val)[0].value = "";
alert('Student Not Found');
document.getElementsByName(val)[0].focus();
}
        


            </script>
<style>
    td{
        text-transform: uppercase;
/*        text-align: center;*/
    }
    #loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #3498db;
  width: 120px;
  height: 120px;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* Add animation to "page content" */
.animate-bottom {
  position: relative;
  -webkit-animation-name: animatebottom;
  -webkit-animation-duration: 1s;
  animation-name: animatebottom;
  animation-duration: 1s
}

@-webkit-keyframes animatebottom {
  from { bottom:-100px; opacity:0 } 
  to { bottom:0px; opacity:1 }
}

@keyframes animatebottom { 
  from{ bottom:-100px; opacity:0 } 
  to{ bottom:0; opacity:1 }
}

#myDiv {
  display: none;
  text-align: center;
}
@media print
{
    .noprint
    {
        display: none;
    }
}
    </style>        <script src="JS/loadPhoto.js"></script>
<!--        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>-->
        <script>
                        $(document).on('keypress', 'input', function(e) {
  if(e.keyCode == 13 && e.target.type !== 'submit') {
    e.preventDefault();
    return $(e.target).blur().focus();
  }

});




function editFields(){
    
    $(".form-control").prop("disabled", false);
    $("#studentRegisterButton").css("display","block");
    
}
            </script>
            <style>
                 .header{
                text-align: center;
/*    background: #f1a92b;*/
    /* background: limegreen; */
    padding: 15px 5px;
    
/*    color: white;*/
background: lightyellow;
color:black;
        box-shadow: 0px 1px 9px black;
            }
                 .login{
                    background: aliceblue;
    padding: 35px;
    box-shadow: 2px 2px 10px;
    border-radius: 10px 20px;
            }
                .groupblock{
                    margin-top: 10px;
                    padding-bottom: 5px;
                    border: 1px outset  green;
                    border-radius: 12px;
                    font-weight: 600;
                }
                h3{
                    font-size: 40px;
                    border-bottom:  1px dotted black;
                }
                div#cont h3{
                    font-size: 30px;
                }
                input{
                    width: 100%;
                    text-transform: uppercase;
                }
                table.table-bordered input{
                    border:none;
                }
                input.form-control,select.form-control{
                    border:1px solid #80bdff;
                }
                input[type=checkbox]{
                    width: 50px;
                }
                select{
                    width: 100%;
                }
                div.table input{
        border: none;
    }
                </style>
    </head>
    <body onload="showPage()" >
        
        <div id="loader" ></div>
              <header>
            <div class="header">
                <div class="container" style="padding:initial">
                <div class="row">
                    <div class="col-sm-2">
                        <img src="img/blogo.jpeg" height="170px" >
                    </div>
                    <div class="col-sm-8">
                        <h1>
                            A.S.M. Degree College                        </h1>
                        <h4>
                            Affiliated to: Raja Mahendra Pratap Singh State University, Aligarh<br />Recognized by UGC                        </h4>
                    </div>
                    <div class="col-sm-2">
                        <img src="img/slogo.jpg" height="170px" >
                    </div>
                        


                    </div>
                    </div>
                <div class="col-sm-12">
                    <a href="index.php.html" class="btn btn-primary">Home</a>
                    <a href="registration.php@new.html" class="btn btn-primary">New Registration</a>
                    <a href="registration.php@old.html" class="btn btn-primary">Old Re-Registration</a>
                    <a href="registration.php@login.html" class="btn btn-primary">Registration Login</a>
                </div>
                
            </div>
        </header>
        <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <br />
                <div style="text-align:center">
                                    </div>
            </div>
        </div>
            </div>
                
        
        
        <div class='container'>
        <div class="row">
            <div class="col-sm-12">
                <br />
                <center>
                    <h3 style="">Re-Registration</h3>
                    <h6>Note:- Kindly Enter Your Admission Details</h6>
                </center>
                <br />
            </div>
        </div>
        
                    
        <form id="myForm" autocomplete="off" method="post" enctype="multipart/form-data">
            <div class='row'>
                <div class='col-sm-12 groupblock'>
                    <div class="row">
                        <div class="col-sm-4"></div>
                        <div class="col-sm-4">
                            <div>Course Name</div>
                            <select name="lastClassName" id="lastClassName" class='form-control'  >
                                <option value="">Select Course</option>

                                <option value=BA>BA</option><option value=BSC(PCM)>BSC(PCM)</option><option value=BSC(ZBC)>BSC(ZBC)</option><option value=BCOM>BCOM</option><option value=BCA>BCA</option><option value=MA(HINDI)>MA(HINDI)</option><option value=MA(ECONOMICS)>MA(ECONOMICS)</option><option value=MSC(MATH)>MSC(MATH)</option><option value=MSC(BOTANY)>MSC(BOTANY)</option><option value=ITI>ITI</option><option value=MA(SOCIOLOGY)>MA(SOCIOLOGY)</option><option value=MA(GEOGRAPHY)>MA(GEOGRAPHY)</option><option value=MA(POLITICAL SCIENCE)>MA(POLITICAL SCIENCE)</option><option value=MSC(Chemistry)>MSC(Chemistry)</option><option value=MCOM>MCOM</option><option value=MA(POLITICAL>MA(POLITICAL</option>                            </select>
                                                    </div>
                        <div class="col-sm-4"></div>
                    </div>
                    <div class="row">
                        <div class="col-sm-4"></div>
                        <div class="col-sm-4">
                            <div>Admission Number</div>
                            <input type='number' autocomplete="off" name="admnumber" id="admnumber" required="" value="" class='form-control'>
                            
                        </div>
                        <div class="col-sm-4"></div>
                    </div>
                    <div class="row">
                        <div class="col-sm-4"></div>
                        <div class="col-sm-4">
                            <div>Mobile Number</div>
                            <input type='number' autocomplete="off" name="mobilenumber" required="" value="" class='form-control'>
                        </div>
                        <div class="col-sm-4"></div>
                    </div>
                                        
                    <br />
                    <div class="row">
                        <div class="col-sm-12" style="text-align:center;">
                            <button type="submit" class='btn btn-primary' name='submit'>Submit</button>
                        </div>
                    </div>
                                        
                </div>
            </div>
        </form>
        </div>
            
        
        
                    
        
        
                
        
                
                <script>
            function showhideSubject(){
                                var div = document.getElementById('basubject');
                                var divcom = document.getElementById('comsubject');
                                var diviti = document.getElementById('itisubject');
                                var course = document.getElementById('lastClassName');
                                if(course.value == "BA"){
                                    div.style.display = "inherit";
                                    divcom.style.display = "inherit";
                                    
                                }
                                else if(course.value == "ITI"){
                                    div.style.display = "none";
                                    divcom.style.display = "none";
                                    diviti.style.visibility = "visible";
                                    diviti.style.display = "contents";
                                    
                                }
                                else{
                                    divcom.style.display = "inherit";
                                    div.style.display = "none";
                                    diviti.style.visibility = "hidden";
                                    
                                }
                            }
                                function makeDate(id,out){
                                    var dd = document.getElementById('dd'+id);
                                    var mm = document.getElementById('mm'+id);
                                    var yy = document.getElementById('yy'+id);
                                    var d = new Date();
                                    if(dd.value == '' || dd.value > 31){

                                        alert('Date can not be more than 31 ');
                                        dd.value = "1";
                                        var odate =(yy.value) + '/' + (mm.value) + '/1';
                                        document.getElementById(out).value =odate;
                                        dd.focus();
                                    }
                                    else if(mm.value == '' || mm.value > 12){
                                            //alert(yy);
                                        alert('month can not be more than 12 ');
                                        mm.value = "1";
                                        var odate =(yy.value) + '/1/' + (dd.value);
                                        document.getElementById(out).value =odate;
                                        mm.focus();
                                    }
                                    else if( yy.value == '' || yy.value.length != 4){
                                        alert('YEAR IS NOT CORRECT');
                                        yy.value = "2000";
                                        yy.focus();
                                    }
                                    else if(yy.value > d.getFullYear() ){
                                        alert('Year can not be more than current');
                                        yy.value = "2018";
                                        yy.focus();
                                    }
                                    else{
                                        var odate =(yy.value) + '-' + (mm.value) + '-' + (dd.value);
                                        //alert(odate);
                                        document.getElementById(out).value =odate;
                                    }
                                    
                                    
                                }
                             
                        function validateDate(){
                            var dobraw = document.getElementById('studentDateOfBirth').value;
                            var dob = new Date(dobraw);
                            var d = new Date();
                            
                            if(document.getElementById('dd2').value > 31){
                                
                                alert('Date can not be more than 31');
                                document.getElementById('dd2').value = "1";
                                document.getElementById('dd2').focus();
                            }
                            if(document.getElementById('mm2').value > 12){
                                
                                alert('month can not be more than 12');
                                document.getElementById('mm2').value = "1";
                                document.getElementById('mm2').focus();
                            }
                            if(document.getElementById('yy2').value > d.getFullYear()){
                                alert('Year can not be more than current');
                                document.getElementById('yy2').value = "2018";
                                document.getElementById('yy2').focus();
                            }
                        }
                        function dispDobinwords(){
                            var dobraw = document.getElementById('studentDateOfBirth').value;
                            var dob = new Date(dobraw);
                            var d = new Date();
                            if(d < dob){
                                alert('Date can not be more than current');
                                document.getElementById('dd2').value = "1";
                                document.getElementById('dd2').focus();
                                
                            }
                            var dobArr = dob.toDateString().split(' ');
                            var dobFormat = dobArr[2] + ' ' + dobArr[1] + ' ' + dobArr[3];
                            document.getElementById('divdobinwords').style.display = "block";
                            document.getElementById('divdobinwords').value = dobFormat;
                        }
                        function showOptionalBlock(){
                        //alert('this');
                        var className = document.getElementById('lastClassName').value;
                        var optionalBlock = document.getElementById('optionalBlock');
                        //if(className == '9' || className == '10' || className == '11' || className == '12'){
                        if(1 == 1){
                            optionalBlock.style.display = 'block';
                            //optionalBlock.style.visibility = 'visible';
                        }
                        else{
                            optionalBlock.style.display = 'none';
                            //optionalBlock.style.visibility = 'hidden';
                        }
                    }
                    
                    function addSame(){
                        document.getElementById('permanentAddress').value = document.getElementById('studentAddress').value;
                    }
                    function validateForm(){
                        $('#studentRegisterButton').prop("disabled", true);
                        $('#studentRegisterButton').html("Submitting...");
                        
                        
                        //var count = $('input[required=""]').length;
                        var inputarr = [["input","nameOfStudent"],
                            ["select","gender"],
                            ["input","dd2"],
                            ["input","mm2"],
                            ["input","yy2"],
                            ["input","sAadharNumber"],
//                            ["select","religion"],
//                            ["select","studentCategory"],
                            ["select","lastClassName"],
//                            ["input","studentLastSchoolName"],
//                            ["input","studentMotherName"],
//                            ["input","smAadharNumber"],
                            ["input","studentFatherName"],
//                            ["input","sfAdharNumber"],
                            ["input","studentTelephoneNumber"],
                            ["input","email"],
//                            ["input","studentAddress"],
                            ["input","permanentAddress"]
                            
                        ];
                        var count = inputarr.length;
                        var submit = 1;
                        for(var i=0;i<count;i++){
                            if($(inputarr[i][0]+'[name="'+inputarr[i][1]+'"]').val() == ""){
                                submit = 0;
                                $(inputarr[i][0]+'[name="'+inputarr[i][1]+'"]').focus();
                                $(inputarr[i][0]+'[name="'+inputarr[i][1]+'"]').css("border","2px solid red");
                                $('#studentRegisterButton').prop("disabled", false);
                                $('#studentRegisterButton').html("Register Student");
                                return;
                            }
                        }
                        
                        
                        if(submit == 1){
                            document.getElementById('myForm').submit();
                        }
                        //alert(count);
                        
                        
                    }
                    $(document).ready(function(){
                        $("input").on('input',function(e){
                            $("input").css("border","1px solid #80bdff");
                        });
                        $("select").on('input',function(e){
                            $("select").css("border","1px solid #80bdff");
                        });
                    });
                    
                    
                        
                                        $(".form-control").prop("autocomplete","off");

                    
                                        
                        </script>
        
        
</body>
</html>

