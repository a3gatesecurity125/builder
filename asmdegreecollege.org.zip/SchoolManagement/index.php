<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>School Management</title>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <!-- Popper JS -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
        <script src ="JS/JSAction.js"></script>
        <style>
            .header{
                text-align: center;
                background: lightyellow;
/*    background: #f1a92b;*/
    /* background: limegreen; */
    padding: 15px 5px;
    color: black;
        box-shadow: 0px 1px 9px black;
            }
            .login{
                    background: aliceblue;
    padding: 35px;
    box-shadow: 2px 2px 10px;
    border-radius: 10px 20px;
            }
            .footer{
/*                    background: #f1a92b;*/
background: lightyellow;
/*    color: white;*/
color: black;
border-top: 1px dashed black;
    position: fixed;
    bottom: 0px;
    width: 100%;
    text-align: center;
    font-size: larger;
    padding: 5px;
            }
            @media(max-width: 600px){
                .header h1{
                    font-size: 25px;
                }
                .header h4{
                    font-size: 15px;
                }
                .header img{
                    width: 100px;
                }
                .footer{
                    position: relative;
                    bottom: inherit;
                }
            }
            ul{
                margin: 5px auto;
            }
            ul li{
                margin: 5px 15px;
                display:  inline;
            }
            
            </style>
    </head>
    <body onload="getCurrentDate();">
                <header>
            <div class="header">
                <div class="container" style="padding:initial">
                <div class="row">
                    <div class="col-sm-2">
                        <img src="img/blogo.jpeg" height="170px" >
                        
                    </div>
                    <div class="col-sm-8">
                        
                        <h1>
                            A.S.M. Degree College                        </h1>
                        <h4>
                            Affiliated to: Raja Mahendra Pratap Singh State University, Aligarh<br />Recognized by UGC                        </h4>
                        
                    </div>
                    <div class="col-sm-2">
                        
                        <img src="img/slogo.jpg" height="170px" >
                        
                    </div>
                        


                    </div>
                    </div>
            </div>
        </header>
                <div class="container">
            <br>
            <div class="" style="text-align:right;">
                <a href="registration.php@login.html" class="btn btn-warning">New Registration Log In</a>
                <a href="../index.html" class="btn btn-primary">Go To Website</a>
            </div>
            <br />
            <div class="row">
                <div class="col-sm-12" >
                    
                    
                </div>
                <div class="col-sm-3"></div>
                <div class="col-sm-6">
                    
                    <div class="login">
                        <h3 style="text-align:center">Fee Deposit Login</h3>
                        <hr />
                        
                    <form action="index.php@login.html" method="post">
                        <div style="text-align: center;">Admin <input type="radio" name="type" value="admin" > Student <input type="radio" checked=""   name="type" value="user" ></div>
                        <div>User Name<input type="text"  name="chkUserName" class="form-control"></div>
                        <div>Password<input type="password" name="chkPassword" class="form-control"></div>
                        <script>
                            function getCurrentDate() {
                                var today = new Date();
                                var dd = today.getDate();
                                var mm = today.getMonth() + 1; //January is 0!
                                var yyyy = today.getFullYear();

                                if (dd < 10) {
                                    dd = '0' + dd
                                }

                                if (mm < 10) {
                                    mm = '0' + mm
                                }

                                today = yyyy + '-' + mm + '-' + dd;
                                document.getElementById('tDate').value = today;
                            }
                        </script>

                        <div>Current Date<input readonly="" type="date" required pattern="DD/MM/YYYY" name="CDate" id="tDate" class="form-control" value=""></div>
                        <br/>
                        <center>     <button type="submit" name="loginButton" class="btn btn-primary">Secure Login</button></center>
                    </form>
                                                </div>
                </div>
                <div class="col-sm-3"></div>
            </div>
            <br />
            
        </div>
                                                
                
        <br />
        <br />
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <ul style="text-align:center">
                        <li><a href="index.php@login.html">Log In</a></li>
                        <li><a href="../about.php.html">About Us</a></li>
                        <li><a href="../fee.php.html">Fees Structure</a></li>
                        
                        <li><a href="../terms.php.html">Terms and Conditions</a></li>
                        <li><a href="../terms.php.html">Privacy Policy</a></li>
                        <li><a href="../terms.php.html">Disclaimer</a></li>
                        <li><a href="../contact.php.html">Contact Us</a></li>
                        
                        
                    </ul>
                </div>
                <div class="col-sm-12">
                    <p style="text-align:center"><b>Note:- </b> This portal is only to collect fees from the student.</p>
                </div>
            </div>
        </div>
        <br />
        <br />
        <footer>
            <div class="footer">
			<p>© 2020 School Management. All rights reserved | Design and Developed by
				<a href="https://andwebtech.com"> A & D Technology.</a>
			</p>
            </div>
        </footer>
    </body>
</html>
