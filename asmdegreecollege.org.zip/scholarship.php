<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>A.S.M. Degree College</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="A.S.M. Degree College" name="keywords">
    <meta content="A.S.M. Degree College" name="description">

    <!-- Favicon -->
    <link href="http://asmdegreecollege.org/img/favicon.ico" rel="icon">
    

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500;600;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    
<!--    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">-->
<!--  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>-->
    
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid bg-dark">
        <div class="row py-2 px-lg-5">
            <div class="col-lg-6 text-center text-lg-left mb-2 mb-lg-0">
                <div class="d-inline-flex align-items-center text-white">
                    <small><i class="fa fa-phone-alt mr-2"></i>+9170881 80051</small>
                    <small class="px-3">|</small>
                    <small><i class="fa fa-envelope mr-2"></i>info@asmdegreecollege.org</small>
                </div>
            </div>
            <div class="col-lg-6 text-center text-lg-right">
                <div class="d-inline-flex align-items-center">
                    <a class="text-white px-2" href="scholarship.php.html">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a class="text-white px-2" href="scholarship.php.html">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a class="text-white px-2" href="scholarship.php.html">
                        <i class="fab fa-linkedin-in"></i>
                    </a>
                    <a class="text-white px-2" href="scholarship.php.html">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a class="text-white pl-2" href="scholarship.php.html">
                        <i class="fab fa-youtube"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid p-0">
        <nav class="navbar navbar-expand-lg bg-white navbar-light py-3 py-lg-0 px-lg-5">
            <a href="index.php.html" class="navbar-brand ml-lg-3">
                <h1 class="m-0 text-uppercase text-primary" style="text-align: right">
                    <table>
                        <tr>
                            <td rowspan="2">
                                <img src="img/slogo.jpg" height="70px"/>
                            </td>
                            <td style="font-size: calc(0.5rem + 0.2vw);width: 100%;">
                                College Code:- 2312
                            </td>
                            
                        </tr>
                        <tr>
                            <td>
                                A.S.M. Degree College
                            </td>
                        </tr>
                        </table>
<!--                    <span><img src="img/slogo.jpg" height="70px"/></span>
                    <span>A.S.M. Degree College</span>
                    
                    <br />
                    <span style="font-size: calc(0.5rem + 0.2vw);width: 100%;">College Code:- 2312</span>-->
                </h1>
                
                
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between px-lg-3" id="navbarCollapse">
                <div class="navbar-nav mx-auto py-0">
                    <a href="index.php.html" class="nav-item nav-link active">Home</a>
<!--                    <a href="about.php" class="nav-item nav-link">About Us</a>-->
                    <div class="nav-item dropdown">
                        <a href="scholarship.php.html#" class="nav-link dropdown-toggle" data-toggle="dropdown">About</a>
                        <div class="dropdown-menu m-0">
                            <a href="about.php.html" class="dropdown-item">About College</a>
                            <a href="faculty.php.html" class="dropdown-item">Our Faculty</a>
                            <a href="fee.php.html" class="dropdown-item">Fee Structure</a>
                            <a href="message.php@type=Founder.html" class="dropdown-item">Founder Message</a>
                            <a href="message.php@type=President.html" class="dropdown-item">President/Chairman Message</a>
                            <a href="message.php@type=Secretary.html" class="dropdown-item">Secretary Message</a>
                            <a href="message.php@type=Director.html" class="dropdown-item">Director Message</a>
                            <a href="message.php@type=Principle.html" class="dropdown-item">Principle Message</a>
                            
                            
                            
                            
                            
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="scholarship.php.html#" class="nav-link dropdown-toggle" data-toggle="dropdown">Department</a>
                        <div class="dropdown-menu m-0">
                            <a href="course.php@name=Computer&#32;Application.html" class="dropdown-item">Computer Application</a>
                            <a href="course.php@name=Science.html" class="dropdown-item">Science </a>
                            <a href="course.php@name=Commerce.html" class="dropdown-item">Commerce </a>
                            <a href="course.php@name=Arts.html" class="dropdown-item">Arts </a>
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="scholarship.php.html#" class="nav-link dropdown-toggle" data-toggle="dropdown">Online</a>
                        <div class="dropdown-menu m-0">
                            <a href="SchoolManagement/registration.php@new.html" class="dropdown-item">New Registration</a>
                            <a href="SchoolManagement/registration.php@login.html" class="dropdown-item">Registration Login</a>
                            <a href="SchoolManagement/index.html" class="dropdown-item">Online Fee Payment</a>
                            <a href="SchoolManagement/index.html" class="dropdown-item">Student/Admin Login</a>
                            <a href="scholarship.php.html" class="dropdown-item">Scholarship Form</a>
                            
                        </div>
                    </div>
                    <a href="gallery.php.html" class="nav-item nav-link">Gallery</a>
                    
                    <a href="contact.php.html" class="nav-item nav-link">Contact Us</a>
                </div>
                
                <a href="SchoolManagement/index.html" class="btn btn-info py-2 px-4 d-lg-block">Pay Fee</a>
                <a href="SchoolManagement/registration.php@new.html" class="btn btn-primary py-2 px-4 d-lg-block">Registration</a>
            </div>
        </nav>
    </div>
    <!-- Navbar End -->

    <div class="jumbotron jumbotron-fluid page-header position-relative overlay-bottom" style="margin-bottom: 0px;">
        <div class="container text-center py-5">
            <h1 class="text-white display-1">Scholarship Form</h1>
            <div class="d-inline-flex text-white mb-5">
                <p class="m-0 text-uppercase"><a class="text-white" href="scholarship.php.html">Home</a></p>
                <i class="fa fa-angle-double-right pt-1 px-3"></i>
                <p class="m-0 text-uppercase">Help</p>
            </div>
        </div>
    </div>


     <!-- Contact Start -->
    <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <div class="row">
                    <div class="col-lg-2"></div>
                    <div class="col-lg-8">
                    <div class="section-title position-relative mb-4">
                        <h6 class="d-inline-block position-relative text-secondary text-uppercase pb-2">Need Help?</h6>
                        <h1 class="display-4">Scholarship Form</h1>
                    </div>
                    <div class="contact-form">
                                                <form method="post">
                            <div class="row">
                                <div class="col-6 form-group">
                                    <input type="text" name="name" class="form-control border-top-0 border-right-0 border-left-0 p-0" placeholder="Your Name" required="required">
                                </div>
                                <div class="col-6 form-group">
                                    <input type="text" name="fname" class="form-control border-top-0 border-right-0 border-left-0 p-0" placeholder="Your Father Name" required="required">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6 form-group">
                                    
                                    <select name="gender" class="form-control border-top-0 border-right-0 border-left-0 p-0" required="required">
                                        <option>Select Gender</option>
                                        <option>Male</option>
                                        <option>Female</option>
                                    </select>
                                </div>
                                <div class="col-6 form-group">
                                    <input type="number" name="aadhar" class="form-control border-top-0 border-right-0 border-left-0 p-0" placeholder="Aadhar Number" required="required">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6 form-group">
                                    <input type="email" name="email" class="form-control border-top-0 border-right-0 border-left-0 p-0" placeholder="Your Email" required="required">
                                </div>
                                <div class="col-6 form-group">
                                    <input type="number" name="mobile" class="form-control border-top-0 border-right-0 border-left-0 p-0" placeholder="Your Mobile" required="required">
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="text" name="address" class="form-control border-top-0 border-right-0 border-left-0 p-0" placeholder="Address" required="required">
                            </div>
                            <div class="row">
                                <div class="col-6 form-group">
                                    <input type="text" name="course" class="form-control border-top-0 border-right-0 border-left-0 p-0" placeholder="Course Name" required="required">
                                </div>
                                <div class="col-6 form-group">
                                    <input type="text" name="college" class="form-control border-top-0 border-right-0 border-left-0 p-0" placeholder="College Name" required="required">
                                </div>
                            </div>
                            
                            <div>
                                <button name="submit" class="btn btn-primary py-3 px-5" type="submit">Submit</button>
                            </div>
                        </form>
                    </div>
                    </div>
                    <div class="col-lg-2"></div>
                    </div>
                </div>
                
                
            </div>
        </div>
    </div>
    <!-- Contact End -->
    
    


    


    


    <!-- Footer Start -->
    <div class="container-fluid position-relative overlay-top bg-dark text-white-50 py-5" style="margin-top: 90px;">
        <div class="container mt-5 pt-5">
            <div class="row">
                <div class="col-md-6 mb-5">
                    <a href="index.php.html" class="navbar-brand">
                        <h1 class="mt-n2 text-uppercase text-white"><span><img src="img/slogo.jpg" height="70px"/></span> A.S.M. Degree College</h1>
                    </a>
                    <p class="m-0">Amrita Singh Memorial Degree College was established in February 2005, on Vasant 
                        Panchimi which celebrates as birthday of (Maa Saraswati). A.S.M. Degree College came into 
                        existence for the future generations, with the aim of marching on the sacrament and disciplined
                        life path by renowned social worker Mr. Y.P. Singh in the memory of his beloved, Promising & 
                        Talented daughter Late. Kumari. Amrita Singh (B.A, L.L.B). Mr. Singh got this inspiration from
                        Late Shri. Hariom Garg.</p>
                </div>
                <div class="col-md-2 ">
                    </div>
                <div class="col-md-4 mb-5">
                    <h3 class="text-white mb-4">Newsletter</h3>
                    <div class="w-100">
                        <div class="input-group">
                            <input type="text" class="form-control border-light" style="padding: 30px;" placeholder="Your Email Address">
                            <div class="input-group-append">
                                <button class="btn btn-primary px-4">Sign Up</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-5">
                    <h3 class="text-white mb-4">Get In Touch</h3>
                    <p><i class="fa fa-map-marker-alt mr-2"></i>NH-93 Tejpur, Aligarh , Uttar Pradesh, India</p>
                    <p><i class="fa fa-phone-alt mr-2"></i>+91 7088180051, 9412275307</p>
                    <p><i class="fa fa-envelope mr-2"></i>info@asmdegreecollege.org</p>
                    <div class="d-flex justify-content-start mt-4">
                        <a class="text-white mr-4" href="scholarship.php.html#"><i class="fab fa-2x fa-twitter"></i></a>
                        <a class="text-white mr-4" href="scholarship.php.html#"><i class="fab fa-2x fa-facebook-f"></i></a>
                        <a class="text-white mr-4" href="scholarship.php.html#"><i class="fab fa-2x fa-linkedin-in"></i></a>
                        <a class="text-white" href="scholarship.php.html#"><i class="fab fa-2x fa-instagram"></i></a>
                    </div>
                </div>
                <div class="col-md-4 mb-5">
                    <h3 class="text-white mb-4">Our Courses</h3>
                    <div class="d-flex flex-column justify-content-start">
                        <a class="text-white-50 mb-2" href="course.php@name=Computer&#32;Application.html"><i class="fa fa-angle-right mr-2"></i>Computer Application</a>
                        <a class="text-white-50 mb-2" href="course.php@name=Science.html"><i class="fa fa-angle-right mr-2"></i>Science Department</a>
                        <a class="text-white-50 mb-2" href="course.php@name=Commerce.html"><i class="fa fa-angle-right mr-2"></i>Commerce Department</a>
                        <a class="text-white-50 mb-2" href="course.php@name=Arts.html"><i class="fa fa-angle-right mr-2"></i>Art Department</a>
                        <a class="text-white-50 mb-2" href="fee.php.html"><i class="fa fa-angle-right mr-2"></i>Fee Structure</a>
                        
                    </div>
                </div>
                <div class="col-md-4 mb-5">
                    <h3 class="text-white mb-4">Quick Links</h3>
                    <div class="d-flex flex-column justify-content-start">
                        <a class="text-white-50 mb-2" href="about.php.html"><i class="fa fa-angle-right mr-2"></i>About Us</a>
                        <a class="text-white-50 mb-2" href="SchoolManagement/registration.php@new.html"><i class="fa fa-angle-right mr-2"></i>Online Registration</a>
                        <a class="text-white-50 mb-2" href="SchoolManagement/registration.php@login.html"><i class="fa fa-angle-right mr-2"></i>Registration Login</a>
                        <a class="text-white-50 mb-2" href="SchoolManagement/index.html"><i class="fa fa-angle-right mr-2"></i>Online Fee Payment</a>
                        <a class="text-white-50 mb-2" href="SchoolManagement/index.html"><i class="fa fa-angle-right mr-2"></i>Student/Admin Login</a>
                        
                        <a class="text-white-50" href="contact.php.html"><i class="fa fa-angle-right mr-2"></i>Contact</a>
                        <a class="text-white-50" href="terms.php.html"><i class="fa fa-angle-right mr-2"></i>Terms and Conditions</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid bg-dark text-white-50 border-top py-4" style="border-color: rgba(256, 256, 256, .1) !important;">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-center text-md-left mb-3 mb-md-0">
                    <p class="m-0">Copyright &copy; <a class="text-white" href="scholarship.php.html#">A.S.M. Degree College</a>. All Rights Reserved.
                    </p>
                </div>
                <div class="col-md-6 text-center text-md-right">
                    <p class="m-0">Designed by <a class="text-white" href="https://andwebtech.com">A & D Technology</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
    <!-- Back to Top -->
    <a href="scholarship.php.html#" class="btn btn-lg btn-primary rounded-0 btn-lg-square back-to-top"><i class="fa fa-angle-double-up"></i></a>
    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>

    


    
</body>

</html>